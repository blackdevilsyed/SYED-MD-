// commands/economy/gamble.js
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../../lib/economy.json");
const getDB = () => { if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({})); return JSON.parse(fs.readFileSync(dbPath)); };
const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
const getUser = (db, id) => { if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 }; return db[id]; };

module.exports = {
  name: "gamble",
  alias: ["bet"],
  category: "Economy",
  desc: "Gamble your money (50/50 chance)",
  usage: ".gamble [amount]",
  execute: async ({ sender, args, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .gamble [amount]");
    const db = getDB();
    const user = getUser(db, sender);
    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount <= 0) return reply("❌ Invalid amount!");
    if (amount > user.wallet) return reply(`❌ Not enough!\nWallet: $${user.wallet}`);
    const win = Math.random() < 0.5;
    if (win) {
      user.wallet += amount;
      await react("🎉");
      await reply(`🎰 *You WON!*\n\n💵 Won: +$${amount}\n👛 Wallet: $${user.wallet}`);
    } else {
      user.wallet -= amount;
      await react("😢");
      await reply(`🎰 *You LOST!*\n\n💸 Lost: -$${amount}\n👛 Wallet: $${user.wallet}`);
    }
    saveDB(db);
  },
};

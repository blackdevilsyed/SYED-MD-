// commands/economy/daily.js
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../../lib/economy.json");
const getDB = () => { if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({})); return JSON.parse(fs.readFileSync(dbPath)); };
const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
const getUser = (db, id) => { if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 }; return db[id]; };

module.exports = {
  name: "daily",
  category: "Economy",
  desc: "Claim daily reward",
  execute: async ({ sender, reply, react }) => {
    const db = getDB();
    const user = getUser(db, sender);
    const now = Date.now();
    const cooldown = 24 * 60 * 60 * 1000;
    if (now - user.lastDaily < cooldown) {
      const left = cooldown - (now - user.lastDaily);
      const h = Math.floor(left / 3600000);
      const m = Math.floor((left % 3600000) / 60000);
      return reply(`⏰ Daily already claimed!\nCome back in *${h}h ${m}m*`);
    }
    const reward = Math.floor(Math.random() * 500) + 500;
    user.wallet += reward;
    user.lastDaily = now;
    saveDB(db);
    await react("🎁");
    await reply(`🎁 *Daily Reward!*\n\n💵 You received: *$${reward}*\n👛 Wallet: $${user.wallet}\n\n> _⚡ SYED MD_`);
  },
};

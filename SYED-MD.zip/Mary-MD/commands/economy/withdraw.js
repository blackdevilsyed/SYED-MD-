// commands/economy/withdraw.js
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../../lib/economy.json");
const getDB = () => { if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({})); return JSON.parse(fs.readFileSync(dbPath)); };
const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
const getUser = (db, id) => { if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 }; return db[id]; };

module.exports = {
  name: "withdraw",
  alias: ["with"],
  category: "Economy",
  desc: "Withdraw money from bank",
  usage: ".withdraw [amount/all]",
  execute: async ({ sender, args, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .withdraw [amount] or .withdraw all");
    const db = getDB();
    const user = getUser(db, sender);
    const amount = args[0] === "all" ? user.bank : parseInt(args[0]);
    if (isNaN(amount) || amount <= 0) return reply("❌ Invalid amount!");
    if (amount > user.bank) return reply(`❌ Not enough in bank!\nBank: $${user.bank}`);
    user.bank -= amount;
    user.wallet += amount;
    saveDB(db);
    await react("💵");
    await reply(`💵 *Withdrew $${amount}*\n\n👛 Wallet: $${user.wallet}\n🏦 Bank: $${user.bank}`);
  },
};

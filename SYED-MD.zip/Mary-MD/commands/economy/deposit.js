// commands/economy/deposit.js
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../../lib/economy.json");
const getDB = () => { if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({})); return JSON.parse(fs.readFileSync(dbPath)); };
const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
const getUser = (db, id) => { if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 }; return db[id]; };

module.exports = {
  name: "deposit",
  alias: ["dep"],
  category: "Economy",
  desc: "Deposit money to bank",
  usage: ".deposit [amount/all]",
  execute: async ({ sender, args, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .deposit [amount] or .deposit all");
    const db = getDB();
    const user = getUser(db, sender);
    const amount = args[0] === "all" ? user.wallet : parseInt(args[0]);
    if (isNaN(amount) || amount <= 0) return reply("❌ Invalid amount!");
    if (amount > user.wallet) return reply(`❌ Not enough in wallet!\nWallet: $${user.wallet}`);
    user.wallet -= amount;
    user.bank += amount;
    saveDB(db);
    await react("🏦");
    await reply(`🏦 *Deposited $${amount}*\n\n👛 Wallet: $${user.wallet}\n🏦 Bank: $${user.bank}`);
  },
};

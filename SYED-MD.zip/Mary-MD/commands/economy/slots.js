// commands/economy/slots.js
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../../lib/economy.json");
const getDB = () => { if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({})); return JSON.parse(fs.readFileSync(dbPath)); };
const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
const getUser = (db, id) => { if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 }; return db[id]; };

const symbols = ["🍒","🍋","🍊","🍇","⭐","💎","7️⃣"];

module.exports = {
  name: "slots",
  category: "Economy",
  desc: "Play slot machine",
  usage: ".slots [amount]",
  execute: async ({ sender, args, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .slots [amount]");
    const db = getDB();
    const user = getUser(db, sender);
    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount <= 0) return reply("❌ Invalid amount!");
    if (amount > user.wallet) return reply(`❌ Not enough!\nWallet: $${user.wallet}`);
    const s1 = symbols[Math.floor(Math.random() * symbols.length)];
    const s2 = symbols[Math.floor(Math.random() * symbols.length)];
    const s3 = symbols[Math.floor(Math.random() * symbols.length)];
    const allMatch = s1 === s2 && s2 === s3;
    const twoMatch = s1 === s2 || s2 === s3 || s1 === s3;
    let result = "", change = 0;
    if (allMatch) { change = amount * 3; result = `🎉 JACKPOT! Won *$${change}*!`; user.wallet += change; }
    else if (twoMatch) { change = amount; result = `✅ Two match! Won *$${change}*!`; user.wallet += change; }
    else { change = amount; result = `❌ No match! Lost *$${change}*`; user.wallet -= change; }
    saveDB(db);
    await react(allMatch ? "🎉" : twoMatch ? "✅" : "😢");
    await reply(`🎰 *Slot Machine*\n\n[ ${s1} | ${s2} | ${s3} ]\n\n${result}\n👛 Wallet: $${user.wallet}`);
  },
};

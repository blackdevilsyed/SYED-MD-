// commands/economy/balance.js
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../../lib/economy.json");

const getDB = () => {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({}));
  return JSON.parse(fs.readFileSync(dbPath));
};

const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

const getUser = (db, id) => {
  if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 };
  return db[id];
};

module.exports = {
  name: "balance",
  alias: ["bal", "wallet"],
  category: "Economy",
  desc: "Check your balance",
  execute: async ({ sender, reply, react }) => {
    await react("💰");
    const db = getDB();
    const user = getUser(db, sender);
    saveDB(db);
    await reply(`💰 *Your Balance*\n\n👛 *Wallet* : $${user.wallet}\n🏦 *Bank*   : $${user.bank}\n💎 *Total*  : $${user.wallet + user.bank}\n\n> _⚡ SYED MD_`);
  },
};

// commands/economy/work.js
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../../lib/economy.json");
const getDB = () => { if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({})); return JSON.parse(fs.readFileSync(dbPath)); };
const saveDB = (db) => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
const getUser = (db, id) => { if (!db[id]) db[id] = { wallet: 0, bank: 0, lastDaily: 0, lastWork: 0 }; return db[id]; };

const jobs = ["programmer 💻","teacher 📚","driver 🚗","chef 👨‍🍳","doctor 👨‍⚕️","YouTuber 🎥","streamer 🎮","trader 📈"];

module.exports = {
  name: "work",
  category: "Economy",
  desc: "Work to earn money",
  execute: async ({ sender, reply, react }) => {
    const db = getDB();
    const user = getUser(db, sender);
    const now = Date.now();
    const cooldown = 30 * 60 * 1000;
    if (now - user.lastWork < cooldown) {
      const left = cooldown - (now - user.lastWork);
      const m = Math.floor(left / 60000);
      return reply(`⏰ You're tired! Rest for *${m} minutes*`);
    }
    const earn = Math.floor(Math.random() * 200) + 100;
    const job = jobs[Math.floor(Math.random() * jobs.length)];
    user.wallet += earn;
    user.lastWork = now;
    saveDB(db);
    await react("💼");
    await reply(`💼 *Work Result*\n\nYou worked as a *${job}*\n💵 Earned: *$${earn}*\n👛 Wallet: $${user.wallet}\n\n> _⚡ SYED MD_`);
  },
};

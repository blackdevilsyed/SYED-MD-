// commands/tools/ping.js
module.exports = {
  name: "ping",
  alias: ["speed"],
  category: "Tools",
  desc: "Check bot ping/speed",
  execute: async ({ sock, from, msg, reply, react }) => {
    const start = Date.now();
    await react("⚡");
    const end = Date.now();
    const ms = end - start;
    await reply(`⚡ *Pong!*\n\n🏓 Speed: *${ms}ms*\n> _SYED MD_`);
  },
};

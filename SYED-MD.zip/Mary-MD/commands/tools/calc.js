// commands/tools/calc.js
module.exports = {
  name: "calc",
  alias: ["calculate"],
  category: "Tools",
  desc: "Calculator",
  usage: ".calc 2+2",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .calc [expression]\nExample: .calc 10*5+2");
    try {
      const expr = args.join(" ").replace(/[^0-9+\-*/().%\s]/g, "");
      const result = eval(expr);
      await react("🔢");
      await reply(`🧮 *Calculator*\n\n📥 Input: \`${expr}\`\n📤 Result: *${result}*`);
    } catch {
      await reply("❌ Invalid expression!");
    }
  },
};

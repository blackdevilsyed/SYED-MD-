// commands/tools/reverse.js
module.exports = {
  name: "reverse",
  category: "Tools",
  desc: "Reverse a text",
  usage: ".reverse [text]",
  execute: async ({ args, reply }) => {
    if (!args.length) return reply("❌ Usage: .reverse [text]");
    const reversed = args.join(" ").split("").reverse().join("");
    await reply(`🔄 *Reversed:*\n${reversed}`);
  },
};

// commands/tools/weather.js
const axios = require("axios");

module.exports = {
  name: "weather",
  category: "Tools",
  desc: "Get weather of any city",
  usage: ".weather [city]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .weather [city]\nExample: .weather Karachi");
    await react("🌤️");
    try {
      const city = args.join(" ");
      const res = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);
      const d = res.data.current_condition[0];
      const area = res.data.nearest_area[0];
      const name = area.areaName[0].value + ", " + area.country[0].value;
      const text = `
🌍 *Weather - ${name}*

🌡️ *Temp*      : ${d.temp_C}°C / ${d.temp_F}°F
🤔 *Feels Like*: ${d.FeelsLikeC}°C
💧 *Humidity*  : ${d.humidity}%
💨 *Wind*      : ${d.windspeedKmph} km/h
👁️ *Visibility*: ${d.visibility} km
☁️ *Condition* : ${d.weatherDesc[0].value}

> _⚡ SYED MD_`;
      await reply(text);
    } catch {
      await reply("❌ City not found! Please check the city name.");
    }
  },
};

// commands/tools/wiki.js
const axios = require("axios");
module.exports = {
  name: "wiki",
  alias: ["wikipedia"],
  category: "Tools",
  desc: "Search Wikipedia",
  usage: ".wiki [topic]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .wiki [topic]");
    await react("📖");
    try {
      const q = args.join(" ");
      const res = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`);
      const d = res.data;
      await reply(`📖 *${d.title}*\n\n${d.extract}\n\n🔗 ${d.content_urls?.desktop?.page || ""}\n\n> _⚡ SYED MD_`);
    } catch {
      await reply("❌ Not found on Wikipedia!");
    }
  },
};

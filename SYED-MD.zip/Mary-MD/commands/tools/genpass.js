// commands/tools/genpass.js
module.exports = {
  name: "genpass",
  alias: ["password"],
  category: "Tools",
  desc: "Generate a strong random password",
  usage: ".genpass [length]",
  execute: async ({ args, reply, react }) => {
    const len = parseInt(args[0]) || 12;
    if (len > 64) return reply("❌ Max length is 64!");
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=";
    let pass = "";
    for (let i = 0; i < len; i++) pass += chars[Math.floor(Math.random() * chars.length)];
    await react("🔐");
    await reply(`🔐 *Generated Password*\n\n\`${pass}\`\n\n_Length: ${len} characters_\n> _⚡ SYED MD_`);
  },
};

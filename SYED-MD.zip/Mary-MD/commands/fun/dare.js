// commands/fun/dare.js
const dares = [
  "Call someone and sing Happy Birthday even if it's not their birthday! 🎂",
  "Send a voice note saying 'I love you' to the last person in your contacts! 💌",
  "Change your WhatsApp profile picture to a funny face for 1 hour! 😂",
  "Send a weird GIF to 3 people in your contacts! 🤣",
  "Write a poem about the person who last texted you! ✍️",
  "Speak in rhymes for the next 3 messages! 🎵",
  "Tell everyone your most embarrassing moment! 😳",
  "Do 20 push-ups right now! 💪",
];

const truths = [
  "What is the most embarrassing thing that has ever happened to you? 😳",
  "Who is your secret crush? 💕",
  "What is the biggest lie you ever told? 🤥",
  "What is something you have never told anyone? 🤫",
  "What is your biggest fear? 😨",
  "Have you ever cheated in an exam? 📝",
  "What is the strangest dream you have ever had? 💭",
  "What is one thing you would change about yourself? 🪞",
];

module.exports = {
  name: "dare",
  category: "Fun",
  desc: "Get a random dare",
  execute: async ({ reply, react }) => {
    await react("😈");
    await reply(`😈 *DARE*\n\n${dares[Math.floor(Math.random() * dares.length)]}\n\n> _⚡ SYED MD_`);
  },
};

// commands/fun/quote.js
const quotes = [
  "The only way to do great work is to love what you do. – Steve Jobs 💡",
  "In the middle of every difficulty lies opportunity. – Einstein ⚡",
  "It does not matter how slowly you go as long as you do not stop. – Confucius 🐢",
  "Life is what happens when you're busy making other plans. – John Lennon 🎵",
  "The future belongs to those who believe in the beauty of their dreams. – Eleanor Roosevelt 🌟",
  "Success is not final, failure is not fatal. – Winston Churchill 👑",
];
module.exports = {
  name: "quote",
  alias: ["animequote"],
  category: "Fun",
  desc: "Get a motivational quote",
  execute: async ({ reply, react }) => {
    await react("💫");
    await reply(`✨ *Quote of the Moment*\n\n_${quotes[Math.floor(Math.random() * quotes.length)]}_`);
  },
};

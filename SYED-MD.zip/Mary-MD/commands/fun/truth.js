// commands/fun/truth.js
const truths = [
  "What is the most embarrassing thing that has ever happened to you? 😳",
  "Who is your secret crush? 💕",
  "What is the biggest lie you ever told? 🤥",
  "What is something you have never told anyone? 🤫",
  "What is your biggest fear? 😨",
  "Have you ever cheated in an exam? 📝",
  "What is the strangest dream you have ever had? 💭",
  "What is one thing you would change about yourself? 🪞",
  "What is the most childish thing you still do? 👶",
  "What is your biggest regret? 💔",
];

module.exports = {
  name: "truth",
  category: "Fun",
  desc: "Get a random truth question",
  execute: async ({ reply, react }) => {
    await react("🤔");
    await reply(`🤔 *TRUTH*\n\n${truths[Math.floor(Math.random() * truths.length)]}\n\n> _⚡ SYED MD_`);
  },
};

// commands/fun/toss.js
module.exports = {
  name: "toss",
  alias: ["coinflip", "flip2"],
  category: "Fun",
  desc: "Flip a coin",
  execute: async ({ reply, react }) => {
    const result = Math.random() < 0.5 ? "🪙 *HEADS*" : "🪙 *TAILS*";
    await react("🪙");
    await reply(`🪙 *Coin Flip Result:*\n\n${result}\n\n> _⚡ SYED MD_`);
  },
};

// commands/fun/8ball.js
const answers = [
  "✅ Yes, definitely!","✅ It is certain!","✅ Without a doubt!",
  "⚠️ Maybe...","⚠️ Ask again later.","⚠️ Cannot predict now.",
  "❌ Don't count on it.","❌ My sources say no.","❌ Very doubtful.",
];
module.exports = {
  name: "8ball",
  category: "Fun",
  desc: "Ask the magic 8 ball",
  usage: ".8ball [question]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❓ Ask a question!\nUsage: .8ball Will I be rich?");
    await react("🎱");
    const q = args.join(" ");
    const a = answers[Math.floor(Math.random() * answers.length)];
    await reply(`🎱 *Magic 8 Ball*\n\n❓ *Q:* ${q}\n${a}`);
  },
};

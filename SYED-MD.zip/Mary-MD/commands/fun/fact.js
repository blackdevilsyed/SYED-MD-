// commands/fun/fact.js
const facts = [
  "Honey never spoils. Archaeologists found 3000-year-old honey in Egyptian tombs! 🍯",
  "Octopuses have three hearts and blue blood! 🐙",
  "A group of flamingos is called a flamboyance! 🦩",
  "Bananas are berries, but strawberries are not! 🍌",
  "The shortest war in history lasted 38–45 minutes! ⚔️",
  "A snail can sleep for 3 years! 🐌",
  "Sharks are older than trees! 🦈",
  "The average person walks about 100,000 miles in their lifetime! 🚶",
];
module.exports = {
  name: "fact",
  category: "Fun",
  desc: "Get a random fact",
  execute: async ({ reply, react }) => {
    await react("🤯");
    await reply(`🌍 *Random Fact*\n\n${facts[Math.floor(Math.random() * facts.length)]}`);
  },
};

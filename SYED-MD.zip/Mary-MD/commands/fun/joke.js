// commands/fun/joke.js
const jokes = [
  "Why don't scientists trust atoms? Because they make up everything! 😂",
  "Why did the math book look so sad? Because it had too many problems! 📚",
  "What do you call a fish without eyes? A fsh! 🐟",
  "Why can't you give Elsa a balloon? Because she'll let it go! 🎈",
  "I told my wife she was drawing her eyebrows too high. She looked surprised! 😲",
  "What do you call a fake noodle? An impasta! 🍝",
  "Why did the scarecrow win an award? Because he was outstanding in his field! 🌾",
  "How do you organize a space party? You planet! 🪐",
];
module.exports = {
  name: "joke",
  category: "Fun",
  desc: "Get a random joke",
  execute: async ({ reply, react }) => {
    await react("😂");
    await reply(`🤣 *Random Joke*\n\n${jokes[Math.floor(Math.random() * jokes.length)]}`);
  },
};

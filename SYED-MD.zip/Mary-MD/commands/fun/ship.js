// commands/fun/ship.js
module.exports = {
  name: "ship",
  alias: ["couple"],
  category: "Fun",
  desc: "Ship two people together",
  usage: ".ship @user1 @user2",
  execute: async ({ msg, reply, react }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    if (!mentioned || mentioned.length < 2) return reply("❌ Tag 2 people!\nUsage: .ship @user1 @user2");
    const percent = Math.floor(Math.random() * 101);
    const bar = "█".repeat(Math.floor(percent / 10)) + "░".repeat(10 - Math.floor(percent / 10));
    const emoji = percent >= 80 ? "💕" : percent >= 50 ? "💞" : percent >= 30 ? "💔" : "😬";
    await react(emoji);
    await reply(`💘 *Ship Meter*\n\n@${mentioned[0].split("@")[0]} ❤️ @${mentioned[1].split("@")[0]}\n\n[${bar}] *${percent}%*\n\n${emoji} ${percent >= 80 ? "Perfect match!" : percent >= 50 ? "Good couple!" : percent >= 30 ? "Maybe..." : "Not a good match!"}\n\n> _⚡ SYED MD_`);
  },
};

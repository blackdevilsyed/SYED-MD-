// commands/general/menu.js

const config = require("../../config/config");
const moment = require("moment");

module.exports = {
  name: "menu",
  alias: ["help", "list"],
  category: "General",
  desc: "Show all commands",
  usage: ".menu",
  ownerOnly: false,

  execute: async ({ reply, react }) => {
    await react("👑");

    const text = `
⬡ ──────────────── ⬡
     *✦ SYED MD ✦*
     _👑 Syed Abdul Wahab Bukhari MD_
⬡ ──────────────── ⬡

┏━━━━━━━━━━━━━━━━━━┓
┃   *⚡ B O T  S T A T U S*
┗━━━━━━━━━━━━━━━━━━┛
┃  👑  *Owner*  ∙ ${config.ownerName}
┃  🔐  *Mode*   ∙ ${config.mode}
┃  ⚙️  *Ver*    ∙ ${config.botVersion}
┃  🕐  *Time*   ∙ ${moment().format("hh:mm A")}
┃  📅  *Date*   ∙ ${moment().format("MMM DD, YYYY")}
╰━━━━━━━━━━━━━━━━━━╯

⬡ ── *C O M M A N D S* ── ⬡

╭─❏ ⚙️ *General* ❐ ─ ⊹
│ ✦ \`.alive\` ✦ \`.menu\` ✦ \`.info\`
│ ✦ \`.afk\` ✦ \`.gif\` ✦ \`.rotate\`
│ ✦ \`.flip\` ✦ \`.mention\` ✦ \`.reload\`
│ ✦ \`.delete\` ✦ \`.chatbot\` ✦ \`.ai\`
│ ✦ \`.games\` ✦ \`.reboot\`
╰─────────── ⊹ _14 cmds_ ⊹

╭─❏ 🔐 *Owner* ❐ ─ ⊹
│ ✦ \`.settings\` ✦ \`.block\` ✦ \`.unblock\`
│ ✦ \`.pp\` ✦ \`.setpp\` ✦ \`.setbio\`
│ ✦ \`.broadcast\` ✦ \`.forward\` ✦ \`.save\`
│ ✦ \`.join\` ✦ \`.vv\` ✦ \`.clearchat\`
│ ✦ \`.disappear\` ✦ \`.vcf\` ✦ \`.update\`
╰─────────── ⊹ _15 cmds_ ⊹

╭─❏ ⚡ *Settings* ❐ ─ ⊹
│ ✦ \`.mode\` ✦ \`.autoread\` ✦ \`.autoreact\`
│ ✦ \`.autotyping\` ✦ \`.antidelete\`
│ ✦ \`.autostatus\` ✦ \`.autobio\`
│ ✦ \`.language\` ✦ \`.platform\`
╰─────────── ⊹ _9 cmds_ ⊹

╭─❏ 👥 *Group* ❐ ─ ⊹
│ ✦ \`.tagall\` ✦ \`.tag\` ✦ \`.tagadmins\`
│ ✦ \`.kick\` ✦ \`.add\` ✦ \`.promote\`
│ ✦ \`.demote\` ✦ \`.mute\` ✦ \`.unmute\`
│ ✦ \`.ginfo\` ✦ \`.link\` ✦ \`.resetlink\`
│ ✦ \`.poll\` ✦ \`.warn\` ✦ \`.warnings\`
│ ✦ \`.antilink\` ✦ \`.antibot\` ✦ \`.antispam\`
│ ✦ \`.welcome\` ✦ \`.goodbye\` ✦ \`.glock\`
│ ✦ \`.gunlock\` ✦ \`.gname\` ✦ \`.gdesc\`
╰─────────── ⊹ _24 cmds_ ⊹

╭─❏ 🛠️ *Utility* ❐ ─ ⊹
│ ✦ \`.uptime\` ✦ \`.ping\` ✦ \`.attp\`
│ ✦ \`.tts\` ✦ \`.upload\` ✦ \`.fancy\`
│ ✦ \`.schedule\` ✦ \`.age\` ✦ \`.cntd\`
│ ✦ \`.filter\` ✦ \`.stickcmd\` ✦ \`.diff\`
╰─────────── ⊹ _12 cmds_ ⊹

╭─❏ ⚡ *Converter* ❐ ─ ⊹
│ ✦ \`.tourl\` ✦ \`.tomp3\` ✦ \`.toptt\`
│ ✦ \`.togif\` ✦ \`.toimage\` ✦ \`.tovn\`
│ ✦ \`.toaudio\`
╰─────────── ⊹ _7 cmds_ ⊹

╭─❏ 🔧 *Tools* ❐ ─ ⊹
│ ✦ \`.weather\` ✦ \`.wiki\` ✦ \`.calc\`
│ ✦ \`.qr\` ✦ \`.ss\` ✦ \`.shorturl\`
│ ✦ \`.ip\` ✦ \`.currency\` ✦ \`.define\`
│ ✦ \`.morse\` ✦ \`.reverse\` ✦ \`.base64encode\`
│ ✦ \`.genpass\` ✦ \`.tempmail\` ✦ \`.tinyurl\`
╰─────────── ⊹ _15 cmds_ ⊹

╭─❏ 🔍 *Search* ❐ ─ ⊹
│ ✦ \`.img\` ✦ \`.google\` ✦ \`.lyrics\`
│ ✦ \`.github\` ✦ \`.npm\` ✦ \`.imdb\`
│ ✦ \`.wallpaper\` ✦ \`.anime\` ✦ \`.news\`
│ ✦ \`.ig\` ✦ \`.find\`
╰─────────── ⊹ _11 cmds_ ⊹

╭─❏ ⚡ *Edit* ❐ ─ ⊹
│ ✦ \`.sticker\` ✦ \`.mp3\` ✦ \`.mp4\`
│ ✦ \`.slow\` ✦ \`.sped\` ✦ \`.bass\`
│ ✦ \`.trim\` ✦ \`.compress\` ✦ \`.resize\`
│ ✦ \`.circle\` ✦ \`.square\` ✦ \`.black\`
╰─────────── ⊹ _12 cmds_ ⊹

╭─❏ 📥 *Download* ❐ ─ ⊹
│ ✦ \`.ytv\` ✦ \`.yta\` ✦ \`.song\`
│ ✦ \`.tiktok\` ✦ \`.insta\` ✦ \`.fb\`
│ ✦ \`.twitter\` ✦ \`.pinterest\` ✦ \`.spotify\`
│ ✦ \`.play\` ✦ \`.video\` ✦ \`.gdrive\`
╰─────────── ⊹ _12 cmds_ ⊹

╭─❏ 💰 *Economy* ❐ ─ ⊹
│ ✦ \`.balance\` ✦ \`.daily\` ✦ \`.work\`
│ ✦ \`.deposit\` ✦ \`.withdraw\` ✦ \`.rob\`
│ ✦ \`.gamble\` ✦ \`.slots\` ✦ \`.pay\`
│ ✦ \`.leaderboard\` ✦ \`.dice\` ✦ \`.coinflip\`
╰─────────── ⊹ _12 cmds_ ⊹

╭─❏ 🎮 *Fun* ❐ ─ ⊹
│ ✦ \`.joke\` ✦ \`.meme\` ✦ \`.fact\`
│ ✦ \`.quote\` ✦ \`.8ball\` ✦ \`.ship\`
│ ✦ \`.dare\` ✦ \`.truth\` ✦ \`.riddle\`
│ ✦ \`.toss\` ✦ \`.rps\` ✦ \`.hack\`
│ ✦ \`.rate\` ✦ \`.couple\` ✦ \`.wyr\`
│ ✦ \`.compliment\` ✦ \`.insult\` ✦ \`.zodiac\`
╰─────────── ⊹ _18 cmds_ ⊹

╭─❏ 🖼️ *Image* ❐ ─ ⊹
│ ✦ \`.blur\` ✦ \`.rmbg\` ✦ \`.grey\`
│ ✦ \`.invert\` ✦ \`.jail\` ✦ \`.wanted\`
│ ✦ \`.triggered\` ✦ \`.wasted\`
╰─────────── ⊹ _8 cmds_ ⊹

╭─❏ 🔎 *Stalk* ❐ ─ ⊹
│ ✦ \`.instastalk\` ✦ \`.gitstalk\` ✦ \`.npmstalk\`
╰─────────── ⊹ _3 cmds_ ⊹

╭─❏ 💬 *WhatsApp* ❐ ─ ⊹
│ ✦ \`.react\` ✦ \`.edit\` ✦ \`.send\` ✦ \`.forward\`
╰─────────── ⊹ _4 cmds_ ⊹

⬡ ── *T E A M* ── ⬡
┃ 👑 *Syed Abdul Wahab Bukhari*
⬡ ──────────────── ⬡
> _⚡ Powered by Syed Abdul Wahab Bukhari MD_
⬡ ──────────────── ⬡`;

    await reply(text);
  },
};

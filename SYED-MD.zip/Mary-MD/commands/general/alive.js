// commands/general/alive.js

const config = require("../../config/config");
const os = require("os");
const moment = require("moment");

module.exports = {
  name: "alive",
  alias: ["ping", "online"],
  category: "General",
  desc: "Check if bot is alive",
  usage: ".alive",
  ownerOnly: false,

  execute: async ({ reply, react }) => {
    await react("⚡");
    const uptime = process.uptime();
    const h = Math.floor(uptime / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    const ram = ((os.totalmem() - os.freemem()) / 1024 / 1024 / 1024).toFixed(2);
    const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);

    const text = `
⬡ ──────────────── ⬡
     *✦ SYED MD ✦*
     _👑 Syed Abdul Wahab Bukhari MD_
⬡ ──────────────── ⬡

┏━━━━━━━━━━━━━━━━━━┓
┃   *⚡ B O T  S T A T U S*
┗━━━━━━━━━━━━━━━━━━┛
┃
┃  👑  *Owner*   ∙ ${config.ownerName}
┃  🔐  *Mode*    ∙ ${config.mode}
┃  🖥️  *Host*    ∙ Linux
┃  📊  *RAM*     ∙ ${ram} GB / ${totalRam} GB
┃  ⚙️  *Ver*     ∙ ${config.botVersion}
┃  🕐  *Time*    ∙ ${moment().format("hh:mm A")}
┃  📅  *Date*    ∙ ${moment().format("MMM DD, YYYY")}
┃  ⏱️  *Uptime*  ∙ ${h}h ${m}m ${s}s
┃
╰━━━━━━━━━━━━━━━━━━╯

> _⚡ Powered by Syed Abdul Wahab Bukhari MD_
⬡ ──────────────── ⬡`;

    await reply(text);
  },
};

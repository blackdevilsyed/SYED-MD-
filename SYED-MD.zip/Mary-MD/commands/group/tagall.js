// commands/group/tagall.js
module.exports = {
  name: "tagall",
  alias: ["everyone"],
  category: "Group",
  desc: "Tag all group members",
  usage: ".tagall [message]",
  groupOnly: true,
  execute: async ({ sock, from, msg, args }) => {
    const meta = await sock.groupMetadata(from);
    const members = meta.participants.map((m) => m.id);
    const text = args.join(" ") || "📢 Attention everyone!";
    let mention = `*${text}*\n\n`;
    for (const m of members) mention += `@${m.split("@")[0]}\n`;
    await sock.sendMessage(from, { text: mention, mentions: members }, { quoted: msg });
  },
};

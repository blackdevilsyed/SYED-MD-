// commands/group/link.js
module.exports = {
  name: "link",
  category: "Group",
  desc: "Get group invite link",
  groupOnly: true,
  execute: async ({ sock, from, reply }) => {
    const code = await sock.groupInviteCode(from);
    await reply(`🔗 *Group Invite Link:*\nhttps://chat.whatsapp.com/${code}`);
  },
};

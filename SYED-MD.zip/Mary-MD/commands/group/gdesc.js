// commands/group/gdesc.js
module.exports = {
  name: "gdesc",
  category: "Group",
  desc: "Change group description",
  groupOnly: true,
  execute: async ({ sock, from, args, reply }) => {
    if (!args.length) return reply("❌ Usage: .gdesc [new description]");
    await sock.groupUpdateDescription(from, args.join(" "));
    await reply(`✅ Group description updated!`);
  },
};

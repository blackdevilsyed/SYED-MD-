// commands/group/promote.js
module.exports = {
  name: "promote",
  category: "Group",
  desc: "Promote member to admin",
  groupOnly: true,
  execute: async ({ sock, from, msg, reply }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    if (!mentioned?.length) return reply("❌ Tag a user!\nUsage: .promote @user");
    await sock.groupParticipantsUpdate(from, mentioned, "promote");
    await reply(`✅ Promoted @${mentioned[0].split("@")[0]} to admin!`);
  },
};

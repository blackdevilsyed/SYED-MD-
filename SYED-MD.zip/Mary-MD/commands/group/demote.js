// commands/group/demote.js
module.exports = {
  name: "demote",
  category: "Group",
  desc: "Demote admin to member",
  groupOnly: true,
  execute: async ({ sock, from, msg, reply }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    if (!mentioned?.length) return reply("❌ Tag a user!\nUsage: .demote @user");
    await sock.groupParticipantsUpdate(from, mentioned, "demote");
    await reply(`✅ Demoted @${mentioned[0].split("@")[0]}!`);
  },
};

// commands/group/unmute.js
module.exports = {
  name: "unmute",
  category: "Group",
  desc: "Unmute group (everyone can send)",
  groupOnly: true,
  execute: async ({ sock, from, reply }) => {
    await sock.groupSettingUpdate(from, "not_announcement");
    await reply("🔊 Group unmuted! Everyone can send messages now.");
  },
};

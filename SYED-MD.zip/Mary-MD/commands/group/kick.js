// commands/group/kick.js
module.exports = {
  name: "kick",
  category: "Group",
  desc: "Remove a member from group",
  usage: ".kick @user",
  groupOnly: true,
  ownerOnly: false,
  execute: async ({ sock, from, msg, reply }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    if (!mentioned || !mentioned.length) return reply("❌ Tag a user to kick!\nUsage: .kick @user");
    await sock.groupParticipantsUpdate(from, mentioned, "remove");
    await reply(`✅ Kicked @${mentioned[0].split("@")[0]} successfully!`);
  },
};

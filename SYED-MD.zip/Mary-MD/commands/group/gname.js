// commands/group/gname.js
module.exports = {
  name: "gname",
  category: "Group",
  desc: "Change group name",
  groupOnly: true,
  execute: async ({ sock, from, args, reply }) => {
    if (!args.length) return reply("❌ Usage: .gname [new name]");
    await sock.groupUpdateSubject(from, args.join(" "));
    await reply(`✅ Group name changed to: *${args.join(" ")}*`);
  },
};

// commands/group/mute.js
module.exports = {
  name: "mute",
  category: "Group",
  desc: "Mute group (admins only can send)",
  groupOnly: true,
  execute: async ({ sock, from, reply }) => {
    await sock.groupSettingUpdate(from, "announcement");
    await reply("🔇 Group muted! Only admins can send messages now.");
  },
};

// commands/group/ginfo.js
module.exports = {
  name: "ginfo",
  alias: ["groupinfo"],
  category: "Group",
  desc: "Get group info",
  groupOnly: true,
  execute: async ({ sock, from, reply }) => {
    const meta = await sock.groupMetadata(from);
    const admins = meta.participants.filter((p) => p.admin).map((p) => "@" + p.id.split("@")[0]).join(", ");
    const text = `
⬡ ── *GROUP INFO* ── ⬡
┃ 📛 *Name*    : ${meta.subject}
┃ 🆔 *JID*     : ${from}
┃ 👥 *Members* : ${meta.participants.length}
┃ 👑 *Admins*  : ${admins}
┃ 📝 *Desc*    : ${meta.desc || "No description"}
┃ 📅 *Created* : ${new Date(meta.creation * 1000).toDateString()}
╰━━━━━━━━━━━━━━━━━━╯
> _⚡ SYED MD_`;
    await reply(text);
  },
};

// commands/converter/tomp3.js
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");

module.exports = {
  name: "tomp3",
  alias: ["toaudio"],
  category: "Converter",
  desc: "Convert video to mp3 audio",
  execute: async ({ sock, msg, from, reply, react }) => {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const isVideo = quoted?.videoMessage || msg.message?.videoMessage;
    if (!isVideo) return reply("❌ Reply to a video!\nUsage: .tomp3");
    await react("⏳");
    try {
      const buffer = await downloadMediaMessage(
        { message: quoted ? { videoMessage: quoted.videoMessage } : msg.message, key: msg.key },
        "buffer", {}
      );
      const tmpIn = `/tmp/vid_${Date.now()}.mp4`;
      const tmpOut = `/tmp/aud_${Date.now()}.mp3`;
      fs.writeFileSync(tmpIn, buffer);
      exec(`ffmpeg -i ${tmpIn} -q:a 0 -map a ${tmpOut}`, async (err) => {
        if (err) return reply("❌ Conversion failed!");
        const audio = fs.readFileSync(tmpOut);
        await sock.sendMessage(from, { audio, mimetype: "audio/mpeg", fileName: "audio.mp3" }, { quoted: msg });
        fs.unlinkSync(tmpIn); fs.unlinkSync(tmpOut);
        await react("✅");
      });
    } catch {
      await reply("❌ Error converting!");
    }
  },
};

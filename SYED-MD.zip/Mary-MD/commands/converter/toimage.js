// commands/converter/toimage.js
const { downloadMediaMessage } = require("@whiskeysockets/baileys");

module.exports = {
  name: "toimage",
  alias: ["toimg"],
  category: "Converter",
  desc: "Convert sticker to image",
  execute: async ({ sock, msg, from, reply, react }) => {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const isSticker = quoted?.stickerMessage || msg.message?.stickerMessage;
    if (!isSticker) return reply("❌ Reply to a sticker!\nUsage: .toimage");
    await react("⏳");
    try {
      const buffer = await downloadMediaMessage(
        { message: quoted ? { stickerMessage: quoted.stickerMessage } : msg.message, key: msg.key },
        "buffer", {}
      );
      await sock.sendMessage(from, { image: buffer, caption: "✅ Converted!\n> _⚡ SYED MD_" }, { quoted: msg });
      await react("✅");
    } catch {
      await reply("❌ Failed to convert!");
    }
  },
};

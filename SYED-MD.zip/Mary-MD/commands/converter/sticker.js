// commands/converter/sticker.js
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");

module.exports = {
  name: "sticker",
  alias: ["s", "stiker"],
  category: "Converter",
  desc: "Convert image/video to sticker",
  usage: ".sticker (reply to image/video)",
  execute: async ({ sock, msg, from, reply, react }) => {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const type = quoted ? Object.keys(quoted)[0] : Object.keys(msg.message || {})[0];
    const isImage = type === "imageMessage";
    const isVideo = type === "videoMessage";
    if (!isImage && !isVideo) return reply("❌ Reply to an image or video!\nUsage: .sticker");

    await react("⏳");
    try {
      const buffer = await downloadMediaMessage(
        { message: quoted ? { [type]: quoted[type] } : msg.message, key: msg.key },
        "buffer", {}
      );
      const tmpIn = path.join("/tmp", `in_${Date.now()}.${isImage ? "jpg" : "mp4"}`);
      const tmpOut = path.join("/tmp", `out_${Date.now()}.webp`);
      fs.writeFileSync(tmpIn, buffer);

      const cmd = isImage
        ? `ffmpeg -i ${tmpIn} -vf scale=512:512 ${tmpOut}`
        : `ffmpeg -i ${tmpIn} -vf scale=512:512 -t 6 -r 15 ${tmpOut}`;

      exec(cmd, async (err) => {
        if (err) return reply("❌ Failed to convert!");
        const webp = fs.readFileSync(tmpOut);
        await sock.sendMessage(from, {
          sticker: webp,
          mimetype: "image/webp",
          stickerAuthor: "SYED MD",
          stickerName: "Powered by Syed Abdul Wahab Bukhari",
        }, { quoted: msg });
        fs.unlinkSync(tmpIn); fs.unlinkSync(tmpOut);
        await react("✅");
      });
    } catch (e) {
      await reply("❌ Error: " + e.message);
    }
  },
};

// commands/image/jail.js
const axios = require("axios");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");

module.exports = {
  name: "jail",
  category: "Image",
  desc: "Put someone in jail",
  execute: async ({ sock, msg, from, reply, react }) => {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const isImage = quoted?.imageMessage || msg.message?.imageMessage;
    if (!isImage) return reply("❌ Reply to an image!\nUsage: .jail");
    await react("⏳");
    try {
      const buffer = await downloadMediaMessage(
        { message: quoted ? { imageMessage: quoted.imageMessage } : msg.message, key: msg.key },
        "buffer", {}
      );
      const base64 = buffer.toString("base64");
      const res = await axios.get(
        `https://api.popcat.xyz/jail?image=data:image/jpeg;base64,${base64}`,
        { responseType: "arraybuffer" }
      );
      await sock.sendMessage(from, {
        image: Buffer.from(res.data),
        caption: "🔒 *JAILED!*\n> _⚡ SYED MD_",
      }, { quoted: msg });
      await react("✅");
    } catch {
      await reply("❌ Failed!");
    }
  },
};

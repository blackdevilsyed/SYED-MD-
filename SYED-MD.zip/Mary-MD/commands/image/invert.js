// commands/image/invert.js
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const Jimp = require("jimp");

module.exports = {
  name: "invert",
  category: "Image",
  desc: "Invert image colors",
  execute: async ({ sock, msg, from, reply, react }) => {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const isImage = quoted?.imageMessage || msg.message?.imageMessage;
    if (!isImage) return reply("❌ Reply to an image!");
    await react("⏳");
    try {
      const buffer = await downloadMediaMessage(
        { message: quoted ? { imageMessage: quoted.imageMessage } : msg.message, key: msg.key },
        "buffer", {}
      );
      const image = await Jimp.read(buffer);
      image.invert();
      const out = await image.getBufferAsync(Jimp.MIME_JPEG);
      await sock.sendMessage(from, { image: out, caption: "✅ Inverted!\n> _⚡ SYED MD_" }, { quoted: msg });
      await react("✅");
    } catch {
      await reply("❌ Failed!");
    }
  },
};

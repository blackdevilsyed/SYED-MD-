// commands/settings/autoreact.js
const config = require("../../config/config");
module.exports = {
  name: "autoreact",
  category: "Settings",
  ownerOnly: true,
  execute: async ({ args, reply }) => {
    config.autoReact = args[0] !== "off";
    await reply(`✅ AutoReact: *${config.autoReact ? "ON" : "OFF"}*`);
  },
};

// commands/settings/autoread.js
const config = require("../../config/config");
module.exports = {
  name: "autoread",
  category: "Settings",
  ownerOnly: true,
  execute: async ({ args, reply }) => {
    config.autoRead = args[0] !== "off";
    await reply(`✅ AutoRead: *${config.autoRead ? "ON" : "OFF"}*`);
  },
};

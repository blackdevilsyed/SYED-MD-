// commands/settings/mode.js
const config = require("../../config/config");
module.exports = {
  name: "mode",
  category: "Settings",
  desc: "Set bot mode (public/private)",
  ownerOnly: true,
  execute: async ({ args, reply }) => {
    if (!args[0] || !["public","private"].includes(args[0]))
      return reply("❌ Usage: .mode public OR .mode private");
    config.mode = args[0];
    await reply(`✅ Bot mode set to *${args[0]}*\n${args[0]==="public"?"🌍 Everyone can use bot":"🔐 Only owner can use bot"}`);
  },
};

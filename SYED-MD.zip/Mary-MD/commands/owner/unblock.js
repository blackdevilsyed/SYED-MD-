// commands/owner/unblock.js
module.exports = {
  name: "unblock",
  category: "Owner",
  desc: "Unblock a user",
  ownerOnly: true,
  execute: async ({ sock, msg, args, reply }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    const target = mentioned?.[0] || (args[0] ? args[0] + "@s.whatsapp.net" : null);
    if (!target) return reply("❌ Usage: .unblock @user");
    await sock.updateBlockStatus(target, "unblock");
    await reply(`✅ Unblocked @${target.split("@")[0]}`);
  },
};

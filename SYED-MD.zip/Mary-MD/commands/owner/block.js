// commands/owner/block.js
module.exports = {
  name: "block",
  category: "Owner",
  desc: "Block a user",
  ownerOnly: true,
  execute: async ({ sock, msg, args, reply }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    const target = mentioned?.[0] || (args[0] ? args[0] + "@s.whatsapp.net" : null);
    if (!target) return reply("❌ Tag or provide number!\nUsage: .block @user");
    await sock.updateBlockStatus(target, "block");
    await reply(`✅ Blocked @${target.split("@")[0]}`);
  },
};

// commands/owner/broadcast.js
module.exports = {
  name: "broadcast",
  alias: ["bc"],
  category: "Owner",
  desc: "Broadcast message to all groups",
  ownerOnly: true,
  execute: async ({ sock, args, reply }) => {
    if (!args.length) return reply("❌ Usage: .broadcast [message]");
    const text = args.join(" ");
    const groups = await sock.groupFetchAllParticipating();
    let count = 0;
    for (const id of Object.keys(groups)) {
      await sock.sendMessage(id, { text: `📢 *Broadcast*\n\n${text}\n\n> _⚡ SYED MD_` });
      count++;
      await new Promise(r => setTimeout(r, 1000));
    }
    await reply(`✅ Broadcast sent to *${count}* groups!`);
  },
};

// commands/owner/setbio.js
module.exports = {
  name: "setbio",
  category: "Owner",
  desc: "Set bot WhatsApp bio",
  usage: ".setbio [text]",
  ownerOnly: true,
  execute: async ({ sock, args, reply }) => {
    if (!args.length) return reply("❌ Usage: .setbio [text]");
    await sock.updateProfileStatus(args.join(" "));
    await reply("✅ Bio updated successfully!");
  },
};

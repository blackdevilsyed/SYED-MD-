// commands/download/ytv.js
const axios = require("axios");

module.exports = {
  name: "ytv",
  alias: ["video", "ytvideo"],
  category: "Download",
  desc: "Download YouTube video",
  usage: ".ytv [youtube link or title]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .ytv [YouTube link or title]");
    await react("⏳");
    try {
      const query = args.join(" ");
      // Using yt-dlp info API wrapper
      const res = await axios.get(`https://api.popcat.xyz/yt?q=${encodeURIComponent(query)}`);
      const d = res.data;
      await reply(`🎬 *YouTube Video Found*\n\n📌 *Title* : ${d.title}\n⏱️ *Duration* : ${d.duration}\n👁️ *Views* : ${d.views}\n\n🔗 *Download Link:*\n${d.url || "Link not available - use yt-dlp on server"}\n\n> _⚡ SYED MD_`);
      await react("✅");
    } catch {
      await reply("❌ Could not fetch video. Check the link or title.");
    }
  },
};

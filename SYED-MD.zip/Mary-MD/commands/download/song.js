// commands/download/song.js
const axios = require("axios");

module.exports = {
  name: "song",
  alias: ["yta", "play", "music"],
  category: "Download",
  desc: "Download YouTube audio/song",
  usage: ".song [song name or link]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .song [song name]\nExample: .song Shape of You");
    await react("⏳");
    try {
      const query = args.join(" ");
      const res = await axios.get(`https://api.popcat.xyz/yt?q=${encodeURIComponent(query)}`);
      const d = res.data;
      await reply(`🎵 *Song Found*\n\n📌 *Title*    : ${d.title}\n⏱️ *Duration* : ${d.duration}\n👁️ *Views*    : ${d.views}\n\n🎧 Use *.ytv* for video or install yt-dlp for audio download.\n🔗 ${d.url || "Link unavailable"}\n\n> _⚡ SYED MD_`);
      await react("✅");
    } catch {
      await reply("❌ Song not found. Try another name.");
    }
  },
};

// commands/download/tiktok.js
const axios = require("axios");

module.exports = {
  name: "tiktok",
  alias: ["tt"],
  category: "Download",
  desc: "Download TikTok video (no watermark)",
  usage: ".tiktok [link]",
  execute: async ({ args, sock, from, msg, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .tiktok [TikTok link]");
    await react("⏳");
    try {
      const res = await axios.get(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(args[0])}`);
      const d = res.data;
      if (!d?.video?.noWatermark) return reply("❌ Could not fetch TikTok video!");
      await sock.sendMessage(from, {
        video: { url: d.video.noWatermark },
        caption: `✅ *TikTok Downloaded!*\n📌 ${d.title || "Video"}\n\n> _⚡ SYED MD_`,
      }, { quoted: msg });
      await react("✅");
    } catch {
      await reply("❌ Failed! Make sure the link is correct.");
    }
  },
};

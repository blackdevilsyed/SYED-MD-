// commands/download/insta.js
const axios = require("axios");

module.exports = {
  name: "insta",
  alias: ["ig", "instagram"],
  category: "Download",
  desc: "Download Instagram photo/video/reel",
  usage: ".insta [link]",
  execute: async ({ args, sock, from, msg, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .insta [Instagram link]");
    await react("⏳");
    try {
      const res = await axios.get(`https://api.dreaded.site/api/igdl?url=${encodeURIComponent(args[0])}`);
      const d = res.data?.result?.[0];
      if (!d?.url) return reply("❌ Could not fetch Instagram media!");
      const isVideo = d.url.includes(".mp4");
      if (isVideo) {
        await sock.sendMessage(from, {
          video: { url: d.url },
          caption: "✅ *Instagram Downloaded!*\n> _⚡ SYED MD_",
        }, { quoted: msg });
      } else {
        await sock.sendMessage(from, {
          image: { url: d.url },
          caption: "✅ *Instagram Downloaded!*\n> _⚡ SYED MD_",
        }, { quoted: msg });
      }
      await react("✅");
    } catch {
      await reply("❌ Failed! Check the link.");
    }
  },
};

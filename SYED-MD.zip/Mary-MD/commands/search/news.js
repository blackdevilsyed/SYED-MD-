// commands/search/news.js
const axios = require("axios");

module.exports = {
  name: "news",
  category: "Search",
  desc: "Get latest news",
  usage: ".news [topic]",
  execute: async ({ args, reply, react }) => {
    await react("📰");
    try {
      const q = args.join(" ") || "world";
      const res = await axios.get(`https://gnews.io/api/v4/search?q=${encodeURIComponent(q)}&lang=en&max=3&apikey=demo`);
      const articles = res.data?.articles;
      if (!articles?.length) return reply("❌ No news found!");
      let text = `📰 *Latest News: ${q}*\n\n`;
      articles.forEach((a, i) => {
        text += `*${i + 1}.* ${a.title}\n_${a.source?.name}_\n🔗 ${a.url}\n\n`;
      });
      text += `> _⚡ SYED MD_`;
      await reply(text);
    } catch {
      await reply("❌ Could not fetch news right now.");
    }
  },
};

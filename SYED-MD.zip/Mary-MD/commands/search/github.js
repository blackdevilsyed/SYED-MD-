// commands/search/github.js
const axios = require("axios");

module.exports = {
  name: "github",
  alias: ["gitstalk", "git"],
  category: "Search",
  desc: "Search GitHub user profile",
  usage: ".github [username]",
  execute: async ({ args, reply, react }) => {
    if (!args[0]) return reply("❌ Usage: .github [username]");
    await react("🐙");
    try {
      const res = await axios.get(`https://api.github.com/users/${args[0]}`);
      const d = res.data;
      const text = `🐙 *GitHub Profile*\n\n👤 *Name*     : ${d.name || "N/A"}\n🆔 *Username* : ${d.login}\n📝 *Bio*      : ${d.bio || "N/A"}\n📍 *Location* : ${d.location || "N/A"}\n🏢 *Company*  : ${d.company || "N/A"}\n📦 *Repos*    : ${d.public_repos}\n👥 *Followers*: ${d.followers}\n➡️ *Following*: ${d.following}\n🔗 *Profile*  : ${d.html_url}\n\n> _⚡ SYED MD_`;
      await reply(text);
    } catch {
      await reply("❌ GitHub user not found!");
    }
  },
};

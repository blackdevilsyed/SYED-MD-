// commands/search/google.js
const axios = require("axios");

module.exports = {
  name: "google",
  alias: ["search", "find"],
  category: "Search",
  desc: "Search Google",
  usage: ".google [query]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .google [query]");
    await react("🔍");
    try {
      const q = args.join(" ");
      const res = await axios.get(`https://api.popcat.xyz/google?q=${encodeURIComponent(q)}`);
      const results = res.data?.slice(0, 3);
      if (!results?.length) return reply("❌ No results found!");
      let text = `🔍 *Google Results for:* _${q}_\n\n`;
      results.forEach((r, i) => {
        text += `*${i + 1}.* ${r.title}\n${r.description}\n🔗 ${r.url}\n\n`;
      });
      text += `> _⚡ SYED MD_`;
      await reply(text);
    } catch {
      await reply("❌ Search failed!");
    }
  },
};

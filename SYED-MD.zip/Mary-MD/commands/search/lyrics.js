// commands/search/lyrics.js
const axios = require("axios");

module.exports = {
  name: "lyrics",
  category: "Search",
  desc: "Get song lyrics",
  usage: ".lyrics [song name]",
  execute: async ({ args, reply, react }) => {
    if (!args.length) return reply("❌ Usage: .lyrics [song name]");
    await react("🎵");
    try {
      const q = args.join(" ");
      const res = await axios.get(`https://api.popcat.xyz/lyrics?song=${encodeURIComponent(q)}`);
      const d = res.data;
      if (!d?.lyrics) return reply("❌ Lyrics not found!");
      const lyrics = d.lyrics.length > 3000 ? d.lyrics.substring(0, 3000) + "\n...(truncated)" : d.lyrics;
      await reply(`🎵 *${d.title}*\n👤 ${d.artist}\n\n${lyrics}\n\n> _⚡ SYED MD_`);
    } catch {
      await reply("❌ Lyrics not found!");
    }
  },
};

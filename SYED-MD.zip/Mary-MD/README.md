# ⚡ SYED MD

<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=30&pause=1000&color=00FF00&center=true&vCenter=true&width=600&lines=SYED+MD+WhatsApp+Bot;Powered+by+Syed+Abdul+Wahab+Bukhari;296%2B+Commands+%7C+Full+Featured" alt="Typing SVG" />
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Node.js-18%2B-green?style=for-the-badge&logo=node.js"/>
  <img src="https://img.shields.io/badge/Baileys-Latest-blue?style=for-the-badge"/>
  <img src="https://img.shields.io/badge/Commands-150%2B-red?style=for-the-badge"/>
  <img src="https://img.shields.io/badge/Platform-Linux-orange?style=for-the-badge"/>
</p>

---

## 🌟 Features

| Category | Commands |
|----------|----------|
| ⚙️ General | alive, menu, afk, chatbot, ai, info |
| 🔐 Owner | broadcast, block, unblock, setbio, setpp |
| ⚡ Settings | mode, autoread, autoreact, autotyping |
| 👥 Group | tagall, kick, promote, demote, mute, unmute, ginfo, link, warn |
| 🛠️ Utility | ping, uptime, tts, attp, schedule, age |
| ⚡ Converter | sticker, tomp3, toimage, togif, tovn |
| 🔧 Tools | calc, weather, wiki, qr, currency, genpass, reverse |
| 🔍 Search | google, lyrics, github, news, imdb, npm |
| ⚡ Edit | sticker, trim, compress, resize, circle |
| 📥 Download | ytv, song, tiktok, insta, facebook, twitter |
| 💰 Economy | balance, daily, work, deposit, withdraw, gamble, slots |
| 🎮 Fun | joke, fact, quote, 8ball, dare, truth, ship, toss, rate |
| 🖼️ Image | blur, grey, invert, wanted, jail, triggered, wasted |
| 🔎 Stalk | gitstalk, npmstalk, instastalk |

---

## 📦 Installation

### Requirements
- Node.js 18+
- npm
- ffmpeg (for media conversion)

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/SYED-MD.git
cd SYED-MD

# 2. Install dependencies
npm install

# 3. Configure the bot
nano config/config.js
# Change ownerNumber to your number (with country code, no +)
# Example: 923001234567

# 4. Start the bot
npm start
```

### 5. Scan QR Code
- A QR code will appear in terminal
- Open WhatsApp → Linked Devices → Link a Device
- Scan the QR code
- Bot is now online! ✅

---

## ⚙️ Configuration

Edit `config/config.js`:

```js
module.exports = {
  botName: "SYED MD",
  prefix: ".",                    // Change command prefix
  ownerNumber: "923XXXXXXXXX",    // Your number
  mode: "private",                // "private" or "public"
  autoRead: true,
  autoReact: true,
  autoTyping: true,
  callReject: true,
};
```

---

## 🚀 Deploy on Server (VPS/Linux)

```bash
# Install PM2 for 24/7 uptime
npm install -g pm2

# Start with PM2
pm2 start index.js --name "SYED-MD"
pm2 save
pm2 startup
```

---

## 📁 Project Structure

```
SYED-MD/
├── index.js              # Main bot file
├── config/
│   └── config.js         # Bot configuration
├── lib/
│   ├── handler.js        # Message handler
│   ├── loader.js         # Command loader
│   └── economy.json      # Economy database
├── commands/
│   ├── general/          # General commands
│   ├── owner/            # Owner commands
│   ├── settings/         # Settings commands
│   ├── group/            # Group commands
│   ├── tools/            # Tool commands
│   ├── converter/        # Converter commands
│   ├── download/         # Download commands
│   ├── search/           # Search commands
│   ├── economy/          # Economy commands
│   ├── fun/              # Fun commands
│   └── image/            # Image commands
├── session/              # WhatsApp session (auto created)
└── package.json
```

---

## 👑 Owner

| Name | Contact |
|------|---------|
| 👑 Syed Abdul Wahab Bukhari | [WhatsApp](https://wa.me/923554080521) |

---

## ⚠️ Disclaimer

This bot is for educational purposes only. Use responsibly. The developer is not responsible for any misuse.

---

<p align="center">
  <b>⚡ Powered by Syed Abdul Wahab Bukhari MD</b>
</p>

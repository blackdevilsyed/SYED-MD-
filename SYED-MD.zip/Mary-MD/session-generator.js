// ╔══════════════════════════════════════════╗
// ║       SYED MD - Session Generator       ║
// ║  Powered by Syed Abdul Wahab Bukhari    ║
// ╚══════════════════════════════════════════╝
//
// Usage:
//   node session-generator.js
//   Then open: http://localhost:3000
//
// Install: npm install @whiskeysockets/baileys express pino qrcode

const express = require("express");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const { Boom } = require("@hapi/boom");
const fs = require("fs");
const path = require("path");
const QRCode = require("qrcode");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let sock = null;
let pairingCode = null;
let sessionReady = false;
let sessionData = null;
let currentStatus = "idle"; // idle | connecting | waiting_code | connected

// ─── HTML Page ────────────────────────────────────────
app.get("/", (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SYED MD — Session Generator</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      background: #0a0a0a;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
      color: #fff;
    }
    .card {
      background: #111;
      border: 1px solid #00ff88;
      border-radius: 16px;
      padding: 40px 32px;
      width: 100%;
      max-width: 480px;
      text-align: center;
      box-shadow: 0 0 40px #00ff8833;
    }
    h1 { color: #00ff88; font-size: 2rem; letter-spacing: 4px; margin-bottom: 4px; }
    .sub { color: #888; font-size: 0.85rem; margin-bottom: 32px; }
    input {
      width: 100%;
      padding: 14px 18px;
      border-radius: 10px;
      border: 1px solid #333;
      background: #1a1a1a;
      color: #fff;
      font-size: 1rem;
      margin-bottom: 16px;
      outline: none;
      transition: border 0.2s;
    }
    input:focus { border-color: #00ff88; }
    button {
      width: 100%;
      padding: 14px;
      border-radius: 10px;
      border: none;
      background: #00ff88;
      color: #000;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      transition: opacity 0.2s;
      margin-bottom: 10px;
    }
    button:hover { opacity: 0.85; }
    button.secondary {
      background: #1a1a1a;
      color: #00ff88;
      border: 1px solid #00ff88;
    }
    #status {
      margin-top: 24px;
      padding: 16px;
      border-radius: 10px;
      background: #1a1a1a;
      border: 1px solid #222;
      min-height: 60px;
      font-size: 0.95rem;
      word-break: break-all;
    }
    .code-box {
      font-size: 2rem;
      letter-spacing: 8px;
      color: #00ff88;
      font-weight: bold;
      padding: 16px;
      background: #0a2a1a;
      border-radius: 10px;
      border: 1px dashed #00ff88;
      margin: 16px 0;
    }
    .session-box {
      background: #0a1a0a;
      border: 1px solid #00ff88;
      border-radius: 10px;
      padding: 16px;
      font-family: monospace;
      font-size: 0.7rem;
      text-align: left;
      word-break: break-all;
      max-height: 200px;
      overflow-y: auto;
      color: #00ff88;
      margin: 12px 0;
    }
    .steps {
      text-align: left;
      background: #1a1a1a;
      border-radius: 10px;
      padding: 16px;
      margin-top: 16px;
      font-size: 0.85rem;
      color: #aaa;
      line-height: 1.8;
    }
    .steps b { color: #00ff88; }
    .success { color: #00ff88; }
    .error { color: #ff4444; }
    .loading { color: #ffaa00; }
    .copy-btn {
      background: #222;
      color: #00ff88;
      border: 1px solid #00ff88;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 0.85rem;
      margin-top: 8px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>⚡ SYED MD</h1>
    <p class="sub">Session Generator — Powered by Syed Abdul Wahab Bukhari</p>

    <div id="form-section">
      <input type="text" id="phone" placeholder="📞 Number (e.g. 923001234567)" maxlength="15"/>
      <button onclick="getCode()">🔑 Get Pairing Code</button>
    </div>

    <div id="status">
      💡 Apna WhatsApp number daalo aur <b>Get Pairing Code</b> click karo.
    </div>

    <div class="steps">
      <b>📱 Steps:</b><br>
      1. Number daalo → Get Pairing Code click karo<br>
      2. WhatsApp → 3 dots → Linked Devices<br>
      3. "Link a Device" → "Link with phone number"<br>
      4. Code enter karo<br>
      5. Session string copy karo → bot mein paste karo
    </div>
  </div>

  <script>
    async function getCode() {
      const phone = document.getElementById("phone").value.replace(/[^0-9]/g, "");
      if (!phone || phone.length < 10) {
        showStatus("❌ Sahi number daalo! Example: 923001234567", "error");
        return;
      }
      showStatus("⏳ Pairing code generate ho raha hai...", "loading");
      try {
        const res = await fetch("/get-code", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone })
        });
        const data = await res.json();
        if (data.code) {
          showStatus(
            '<b class="success">✅ Pairing Code Ready!</b><br>' +
            '<div class="code-box">' + data.code + '</div>' +
            '<small style="color:#888">WhatsApp mein yeh code enter karo</small>',
            "success"
          );
          checkSession();
        } else {
          showStatus("❌ Error: " + (data.error || "Unknown"), "error");
        }
      } catch (e) {
        showStatus("❌ Server error: " + e.message, "error");
      }
    }

    function checkSession() {
      const interval = setInterval(async () => {
        const res = await fetch("/session-status");
        const data = await res.json();
        if (data.ready && data.session) {
          clearInterval(interval);
          showStatus(
            '<b class="success">🎉 Connected! Session Ready!</b><br>' +
            '<div class="session-box" id="sess">' + data.session + '</div>' +
            '<button class="copy-btn" onclick="copySession()">📋 Copy Session</button><br>' +
            '<small style="color:#888;margin-top:8px;display:block">Yeh string SYED-MD ke session/ folder mein save karo</small>',
            "success"
          );
        }
      }, 3000);
    }

    function copySession() {
      const text = document.getElementById("sess").innerText;
      navigator.clipboard.writeText(text).then(() => {
        alert("✅ Session copied!");
      });
    }

    function showStatus(html, type) {
      const el = document.getElementById("status");
      el.innerHTML = html;
      el.style.borderColor = type === "success" ? "#00ff88" : type === "error" ? "#ff4444" : "#ffaa00";
    }
  </script>
</body>
</html>`);
});

// ─── Get Pairing Code API ─────────────────────────────
app.post("/get-code", async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.json({ error: "Number required" });

    const sessionPath = "./temp-session";
    if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    sock = makeWASocket({
      version,
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,
      auth: state,
      browser: ["SYED MD", "Chrome", "1.0.0"],
    });

    sock.ev.on("creds.update", async () => {
      await saveCreds();
      // Read session and encode
      try {
        const credsPath = path.join(sessionPath, "creds.json");
        if (fs.existsSync(credsPath)) {
          const creds = fs.readFileSync(credsPath, "utf-8");
          sessionData = Buffer.from(creds).toString("base64");
        }
      } catch {}
    });

    sock.ev.on("connection.update", (update) => {
      const { connection, lastDisconnect } = update;
      if (connection === "open") {
        sessionReady = true;
        currentStatus = "connected";
        // Save final session
        try {
          const credsPath = path.join(sessionPath, "creds.json");
          if (fs.existsSync(credsPath)) {
            const creds = fs.readFileSync(credsPath, "utf-8");
            sessionData = "SYED_MD_SESSION::" + Buffer.from(creds).toString("base64");
          }
        } catch {}
      }
    });

    // Wait a moment then request pairing code
    await new Promise(r => setTimeout(r, 2000));
    const code = await sock.requestPairingCode(phone.replace(/[^0-9]/g, ""));
    pairingCode = code?.match(/.{1,4}/g)?.join("-") || code;
    currentStatus = "waiting_code";

    res.json({ code: pairingCode });
  } catch (err) {
    res.json({ error: err.message });
  }
});

// ─── Session Status API ───────────────────────────────
app.get("/session-status", (req, res) => {
  res.json({
    ready: sessionReady,
    session: sessionData || null,
    status: currentStatus,
  });
});

// ─── Start Server ─────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════╗
║     SYED MD — Session Generator      ║
╚══════════════════════════════════════╝

✅ Server start ho gaya!
🌐 Browser mein yeh open karo:

   http://localhost:${PORT}

⚡ Powered by Syed Abdul Wahab Bukhari MD
  `);
});

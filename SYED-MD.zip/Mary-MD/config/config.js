// ╔══════════════════════════════════════╗
// ║         SYED MD - Configuration      ║
// ║   Powered by Syed Abdul Wahab        ║
// ║         Bukhari MD                   ║
// ╚══════════════════════════════════════╝

module.exports = {
  // Bot Info
  botName: "SYED MD",
  botVersion: "v1.0.0",
  prefix: ".",

  // Owner Info
  ownerName: "Syed Abdul Wahab Bukhari",
  ownerNumber: "923049730127",
  ownerContact: "wa.me/923049730127",

  // Bot Settings
  mode: "private",
  autoRead: true,
  autoTyping: true,
  autoRecording: false,
  autoReact: true,
  antiDelete: true,
  callReject: true,
  autoStatus: false,
  autoBio: false,

  // Welcome/Goodbye
  welcomeMsg: "⬡ ──────────────── ⬡\n*✦ SYED MD ✦*\n⬡ ──────────────── ⬡\n\n👋 Welcome to the group!\n_Powered by Syed Abdul Wahab Bukhari MD_",
  goodbyeMsg: "👋 Goodbye! Hope to see you again.\n_SYED MD_",

  // Anti Settings
  antiLink: false,
  antiBadWord: false,
  antiSpam: false,
  antiFake: false,
  antiBot: false,
  antiSticker: false,
};

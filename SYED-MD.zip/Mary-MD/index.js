// ╔══════════════════════════════════════════╗
// ║            S Y E D  M D                 ║
// ║   Powered by Syed Abdul Wahab Bukhari   ║
// ╚══════════════════════════════════════════╝

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
} = require("@whiskeysockets/baileys");

const pino = require("pino");
const { Boom } = require("@hapi/boom");
const readline = require("readline");
const chalk = require("chalk");
const config = require("./config/config");
const { loadCommands } = require("./lib/loader");
const { handleMessage } = require("./lib/handler");

const store = makeInMemoryStore({
  logger: pino().child({ level: "silent", stream: "store" }),
});

// ─── Input Helper ─────────────────────────────────────
const question = (text) => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(text, (ans) => { rl.close(); resolve(ans); }));
};

// ─── Main Bot Start ───────────────────────────────────
const startBot = async () => {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  console.log(chalk.cyan(`
╔══════════════════════════════════════╗
║           S Y E D   M D              ║
║  Powered by Syed Abdul Wahab Bukhari ║
╚══════════════════════════════════════╝
  Version  : ${config.botVersion}
  Prefix   : ${config.prefix}
  Mode     : ${config.mode}
══════════════════════════════════════
  `));

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: state,
    browser: ["SYED MD", "Chrome", "1.0.0"],
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id);
        return msg?.message || undefined;
      }
      return { conversation: "hello" };
    },
  });

  store?.bind(sock.ev);

  // ─── Pairing Code System ──────────────────────────
  if (!sock.authState.creds.registered) {
    console.log(chalk.yellow("\n📱  PAIRING CODE MODE"));
    console.log(chalk.yellow("══════════════════════════════════════"));

    let phoneNumber = await question(
      chalk.green(
        "📞 Apna WhatsApp number daalo\n" +
        "   (country code ke saath, + ke bina)\n" +
        "   Example: 923001234567\n\n" +
        "   ➤ Number: "
      )
    );

    phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

    if (!phoneNumber || phoneNumber.length < 10) {
      console.log(chalk.red("❌ Galat number! Dobara start karo."));
      process.exit(1);
    }

    console.log(chalk.cyan("\n⏳ Code generate ho raha hai..."));

    try {
      const code = await sock.requestPairingCode(phoneNumber);
      const formatted = code?.match(/.{1,4}/g)?.join("-") || code;

      console.log(chalk.greenBright(`
╔══════════════════════════════════════╗
║         🔑  PAIRING CODE             ║
╠══════════════════════════════════════╣
║                                      ║
║        ${formatted.padEnd(30)}║
║                                      ║
╚══════════════════════════════════════╝

📱 Yeh steps follow karo:
   1. WhatsApp kholo
   2. Upar 3 dots → Linked Devices
   3. "Link a Device" tap karo
   4. "Link with phone number instead" tap karo
   5. Yeh code enter karo ➜ ${chalk.bold.yellow(formatted)}

⏳ Code sirf 60 seconds valid hai!
      `));

    } catch (err) {
      console.log(chalk.red("❌ Error: " + err.message));
      console.log(chalk.yellow("💡 Number format sahi karo: 923001234567"));
      process.exit(1);
    }
  }

  // ─── Load Commands ────────────────────────────────
  const commands = loadCommands();

  // ─── Connection Events ────────────────────────────
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = code !== DisconnectReason.loggedOut;
      if (shouldReconnect) {
        console.log(chalk.yellow("🔄 Reconnecting..."));
        startBot();
      } else {
        console.log(chalk.red("🚪 Logged out! 'session' folder delete karo aur dobara start karo."));
        process.exit(0);
      }
    } else if (connection === "open") {
      console.log(chalk.green(`
✅ SYED MD Connected!
👑 Owner   : ${config.ownerName}
📦 Commands: ${commands.size}
⚡ Powered by Syed Abdul Wahab Bukhari MD
      `));

      await sock.sendMessage(config.ownerNumber + "@s.whatsapp.net", {
        text:
          `⬡ ──────────────── ⬡\n` +
          `*✦ SYED MD ✦*\n` +
          `⬡ ──────────────── ⬡\n\n` +
          `✅ Bot *ONLINE* ho gaya!\n\n` +
          `👑 *Owner*   ∙ ${config.ownerName}\n` +
          `⚙️  *Ver*     ∙ ${config.botVersion}\n` +
          `📦 *Cmds*   ∙ ${commands.size}\n` +
          `🔐 *Mode*   ∙ ${config.mode}\n\n` +
          `_⚡ Powered by Syed Abdul Wahab Bukhari MD_`,
      });

    } else if (connection === "connecting") {
      console.log(chalk.yellow("🔗 WhatsApp se connect ho raha hai..."));
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // ─── Messages ─────────────────────────────────────
  sock.ev.on("messages.upsert", async (m) => {
    await handleMessage(sock, m, commands, store);
  });

  // ─── Auto Reject Calls ────────────────────────────
  sock.ev.on("call", async (calls) => {
    if (!config.callReject) return;
    for (const call of calls) {
      if (call.status === "offer") {
        await sock.rejectCall(call.id, call.from);
        await sock.sendMessage(call.from, {
          text: `❌ *Call Reject ho gaya!*\n_SYED MD calls accept nahi karta._\n_Owner: ${config.ownerContact}_`,
        });
      }
    }
  });

  // ─── Welcome / Goodbye ────────────────────────────
  sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
    for (const participant of participants) {
      if (action === "add") {
        await sock.sendMessage(id, {
          text: `${config.welcomeMsg}\n\n@${participant.split("@")[0]}`,
          mentions: [participant],
        });
      } else if (action === "remove") {
        await sock.sendMessage(id, {
          text: `${config.goodbyeMsg}\n\n@${participant.split("@")[0]}`,
          mentions: [participant],
        });
      }
    }
  });

  return sock;
};

startBot().catch(console.error);
